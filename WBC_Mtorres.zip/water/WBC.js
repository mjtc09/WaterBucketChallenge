function WBC()
{
    // This 2d matrix is used to keep track of the values already visited and avoid repetitions.
    // Esta matriz 2d se utiliza para llevar la cuenta de los valores ya visitados y evitar repeticiones.

    let x = parseFloat(document.getElementById('x').value);
    let y = parseFloat(document.getElementById('y').value);
    let z = parseFloat(document.getElementById('z').value);

    let resultInput = document.getElementById('result');

    let m = new Array(1000);
    for(let i=0;i<1000;i++){
        m[i]=new Array(1000);
        for(let j=0;j<1000;j++)
        {
            m[i][j]=-1;
        }
    }

    let isSolvable = false;
    let path = [];

    let q = []; // To maintain states - Mantener los estados
    q.push([0,0]); // Initializing with initial state - Inicialización con estado inicial

    while (q.length!=0) {

        let u = q[0]; // Current state - Estado Actual 

        q.shift(); // Pop off used state - Salir del estado usado

        // Doesn't met bucket constraints - No cumple las restricciones del cubo
        if ((u[0] > x || u[1] > y ||
            u[0] < 0 || u[1] < 0))
            continue;

        // If this state is already visited - Si este estado ya ha sido visitado
        if (m[u[0]][u[1]] > -1)
            continue;

        // Filling the vector for constructing - Rellenar el vector para construir
        // The way to the solution - La vía de la solución
        path.push([u[0],u[1]]);

        // Marking current state as visited - Marcar el estado actual como visitado
          
        m[u[0]][u[1]] = 1;
          
        // System.out.println(m.get(new Pair(u.first, u.second)));
        // The above instruction prints the argument passed to it - La instrucción anterior imprime el argumento que se le pasa
          
        // If we reach solution state, put ans=1 - Si llegamos al estado solución, poner ans=1
        if (u[0] == z || u[1] == z) {
            isSolvable = true;
            if (u[0] == z) {
                if (u[1] != 0)

                    // Fill final state - Llenar estado final
                    path.push([u[0],0]);
            }
            else {
                if (u[0] != 0)

                    // Fill final state - Llenar estado final
                    path.push([0,u[1]]);
            }

            // Print the way to the solution - Imprimir el camino hacia la solución
            let sz = path.length;
            for (let i = 0; i < sz; i++) {
                resultInput.value += `(${path[i][0]},${path[i],[1]})`
            }
            break;
        }

        // If we have not reached final state, then, start developing intermediate states to reach solution state
        // Si no hemos alcanzado el estado final, entonces, empezar a desarrollar estados intermedios para alcanzar el estado solución
       
        q.push([u[0],y]); // fill Bucket X - Llenar la cubeta X
        q.push([x,u[1]]); // fill Bucket Y - Llenar la cubeta Y

        for (let ap = 0; ap <= Math.max(x, y); ap++) {

            // Pour amount ap from BucketY to BucketX
            let c = u[0] + ap;
            let d = u[1] - ap;

            // Check if this state is possible or not
            if (c == x || (d == 0 && d >= 0))
                q.push([c,d]);

            // Pour amount ap from BucketX to BucketY
            c = u[0] - ap;
            d = u[1] + ap;

            // Check if this state is possible or not
            if ((c == 0 && c >= 0) || d == y)
                q.push([c,d]);
        }

        q.push([x,0]); // Empty BucketY - Vaciar X
        q.push([0,y]); // Empty BucketX - Vaciar Y
    }

    // No, solution exists if ans=0 - No existe solución si ans=0
    if (!isSolvable) {
        resultInput.value = "No solution, try again!"
    }
    
}
